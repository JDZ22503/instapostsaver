#!/usr/bin/env python3
"""
Instagram scraper using Instaloader WITHOUT login
Works for PUBLIC posts - NO LOGIN, NO IP BLACKLIST!
"""
import sys
import json
from instaloader import Instaloader, Post

def get_instagram_media_no_login(url):
    """
    Fetch Instagram media using Instaloader WITHOUT login
    Works for public posts only
    """
    try:
        # Extract shortcode from URL
        import re
        match = re.search(r'/(?:p|reel|reels|tv)/([a-zA-Z0-9_-]+)', url)
        if not match:
            return {"success": False, "message": "Invalid Instagram URL"}
        
        shortcode = match.group(1)
        
        print(f"📸 Fetching PUBLIC post {shortcode} WITHOUT login...", file=sys.stderr)
        
        # Create Instaloader instance WITHOUT login
        L = Instaloader(
            download_pictures=False,
            download_videos=False,
            download_video_thumbnails=False,
            download_comments=False,
            save_metadata=False,
            compress_json=False,
            quiet=True
        )
        
        # No login! Just fetch public post
        post = Post.from_shortcode(L.context, shortcode)
        
        # Check if post is accessible
        if not post:
            return {
                "success": False,
                "message": "Could not access post. It might be private or deleted"
            }
        
        media_items = []
        
        # Check if it's a carousel (multiple images/videos)
        if post.typename == 'GraphSidecar':
            # Carousel post - multiple images/videos
            print(f"📸 Carousel post with {post.mediacount} items", file=sys.stderr)
            
            for node in post.get_sidecar_nodes():
                if node.is_video:
                    media_items.append({
                        "type": "video",
                        "url": node.video_url,
                        "thumbnail": node.display_url,
                        "width": None,
                        "height": None
                    })
                else:
                    media_items.append({
                        "type": "image",
                        "url": node.display_url,
                        "thumbnail": None,
                        "width": None,
                        "height": None
                    })
        
        # Single image or video
        elif post.is_video:
            media_items.append({
                "type": "video",
                "url": post.video_url,
                "thumbnail": post.url,
                "width": None,
                "height": None
            })
        else:
            media_items.append({
                "type": "image",
                "url": post.url,
                "thumbnail": None,
                "width": None,
                "height": None
            })
        
        # Get caption
        caption = post.caption if post.caption else "Instagram Media"
        
        # Determine overall type
        media_type = "carousel" if len(media_items) > 1 else media_items[0]["type"]
        
        print(f"✅ Success! Fetched {media_type} with {len(media_items)} item(s) (no login required)", file=sys.stderr)
        
        return {
            "success": True,
            "id": shortcode,
            "type": media_type,
            "metadata": {
                "title": caption[:200] if len(caption) > 200 else caption
            },
            "media": media_items
        }
        
    except Exception as e:
        error_msg = str(e)
        
        # Check for specific errors
        if "login" in error_msg.lower():
            return {
                "success": False,
                "message": "Post is private and requires login"
            }
        elif "not found" in error_msg.lower() or "404" in error_msg:
            return {
                "success": False,
                "message": "Post not found or deleted"
            }
        else:
            return {
                "success": False,
                "message": f"Error: {error_msg}"
            }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"success": False, "message": "No URL provided"}))
        sys.exit(1)
    
    url = sys.argv[1]
    result = get_instagram_media_no_login(url)
    print(json.dumps(result))
