export const DISCLAIMER_TEXT = {
    title: "Legal Disclaimer",
    content: "This app is for personal and educational use only.\n\nUsers are responsible for respecting copyright and content ownership. This app is not affiliated with, endorsed by, or sponsored by Instagram.\n\nBy continuing, you agree that you will not use this app to violate any terms of service or copyright laws.",
    buttonLabel: "I Accept & Continue"
};

// ============================================
// API CONFIGURATION
// ============================================
// IMPORTANT: Change this based on your environment!
//
// For LOCAL DEVELOPMENT (testing on same WiFi):
//   - Find your computer's IP: Run 'ipconfig' on Windows
//   - Use: "http://YOUR-COMPUTER-IP:3000/api/v1"
//   - Example: "http://192.168.0.75:3000/api/v1"
//
// For PRODUCTION (deployed on server):
//   - Use your server's domain: "https://api.yourdomain.com/api/v1"
//   - OR server IP: "http://YOUR-SERVER-IP/api/v1"
//   - Example: "https://api.instagramsaver.com/api/v1"
//
// ============================================

// 🔧 CHANGE THIS TO YOUR BACKEND URL:
export const API_BASE_URL = "http://192.168.0.75:3000/api/v1"; // <-- CHANGE THIS!

// Example configurations:
// Local Dev: "http://192.168.0.75:3000/api/v1"
// Production: "https://api.yourdomain.com/api/v1"
// DigitalOcean: "http://123.45.67.89/api/v1"

