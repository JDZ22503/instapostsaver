import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, ScrollView, Image, Alert, ActivityIndicator, Modal, Pressable } from 'react-native';
import * as FileSystem from 'expo-file-system/legacy';
import * as MediaLibrary from 'expo-media-library';
import { useVideoPlayer, VideoView } from 'expo-video';
import { Ionicons } from '@expo/vector-icons';
import { API_BASE_URL } from '../constants/Config';

export default function HomeScreen({ navigation }) {
    const [url, setUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [downloading, setDownloading] = useState(false);
    const [mediaData, setMediaData] = useState(null);
    const [selectedItems, setSelectedItems] = useState([]);
    const [previewItem, setPreviewItem] = useState(null);
    const [showPreview, setShowPreview] = useState(false);

    // Setup Video Player for preview
    const videoSource = previewItem?.type === 'video'
        ? `${API_BASE_URL.replace('/api/v1', '')}/api/v1/download?url=${encodeURIComponent(previewItem.url)}`
        : null;

    const player = useVideoPlayer(videoSource, player => {
        player.loop = true;
        player.play();
    });

    const handleSearch = async () => {
        if (!url.trim()) {
            Alert.alert('Error', 'Please enter an Instagram URL');
            return;
        }

        try {
            setLoading(true);
            setMediaData(null);
            setSelectedItems([]);

            const response = await fetch(`${API_BASE_URL}/fetch?url=${encodeURIComponent(url.trim())}`);

            const data = await response.json();

            if (data.success) {
                setMediaData(data);
            } else {
                Alert.alert('Error', data.message || 'Failed to fetch media');
            }
        } catch (error) {
            console.error('Fetch error:', error);
            Alert.alert('Error', 'Could not connect to server. Make sure backend is running.');
        } finally {
            setLoading(false);
        }
    };

    const toggleSelection = (index) => {
        setSelectedItems(prev => {
            if (prev.includes(index)) {
                return prev.filter(i => i !== index);
            } else {
                return [...prev, index];
            }
        });
    };

    const selectAll = () => {
        if (!mediaData) return;
        if (selectedItems.length === mediaData.media.length) {
            setSelectedItems([]);
        } else {
            setSelectedItems(mediaData.media.map((_, index) => index));
        }
    };

    const handleLongPress = (item) => {
        setPreviewItem(item);
        setShowPreview(true);
    };

    const downloadFile = async (url, index) => {
        const BACKEND_URL = API_BASE_URL.replace('/api/v1', '');
        const proxyUrl = `${BACKEND_URL}/api/v1/download?url=${encodeURIComponent(url)}`;
        const extension = mediaData.media[index].type === 'video' ? 'mp4' : 'jpg';
        const fileName = `insta_${Date.now()}_${index}.${extension}`;
        const downloadPath = FileSystem.documentDirectory + fileName;

        await FileSystem.downloadAsync(proxyUrl, downloadPath);
        await MediaLibrary.saveToLibraryAsync(downloadPath);
    };

    const handleDownload = async () => {
        if (selectedItems.length === 0) {
            Alert.alert("No Selection", "Please select at least one image to download");
            return;
        }

        try {
            setDownloading(true);

            const { status } = await MediaLibrary.requestPermissionsAsync(true);
            if (status !== 'granted') {
                Alert.alert("Permission Error", "Need gallery access to save media.");
                return;
            }

            for (const index of selectedItems) {
                await downloadFile(mediaData.media[index].url, index);
            }

            Alert.alert("Success", `Downloaded ${selectedItems.length} item(s) to Gallery!`);
            setSelectedItems([]);

        } catch (error) {
            console.error("Download failure:", error);
            Alert.alert("Download Error", "Could not save media.");
        } finally {
            setDownloading(false);
        }
    };

    const renderGridItem = (item, index) => {
        const isSelected = selectedItems.includes(index);

        return (
            <Pressable
                key={index}
                style={styles.gridItem}
                onPress={() => toggleSelection(index)}
                onLongPress={() => handleLongPress(item)}
            >
                <Image
                    source={{ uri: item.url }}
                    style={styles.gridImage}
                    resizeMode="cover"
                />

                <View style={styles.checkboxContainer}>
                    <View style={[styles.checkbox, isSelected && styles.checkboxSelected]}>
                        {isSelected && <Ionicons name="checkmark" size={14} color="#fff" />}
                    </View>
                </View>

                {item.type === 'video' && (
                    <View style={styles.videoIndicator}>
                        <Ionicons name="play-circle" size={24} color="rgba(255,255,255,0.9)" />
                    </View>
                )}

                {isSelected && <View style={styles.selectionOverlay} />}
            </Pressable>
        );
    };

    return (
        <View style={styles.wrapper}>
            <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
                {/* Header */}
                <View style={styles.header}>
                    <Text style={styles.logo}>Instagram Saver</Text>
                    <Text style={styles.subtitle}>Download Reels & Photos</Text>
                </View>

                {/* Search Section */}
                <View style={styles.searchSection}>
                    <TextInput
                        style={styles.input}
                        placeholder="Paste Instagram URL here..."
                        value={url}
                        onChangeText={setUrl}
                        autoCapitalize="none"
                        autoCorrect={false}
                    />
                    <TouchableOpacity
                        style={styles.searchButton}
                        onPress={handleSearch}
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator color="#fff" size="small" />
                        ) : (
                            <Ionicons name="search" size={24} color="#fff" />
                        )}
                    </TouchableOpacity>
                </View>

                {/* Results Section */}
                {mediaData && (
                    <>
                        <View style={styles.resultsHeader}>
                            <Text style={styles.resultsTitle}>
                                {mediaData.media.length} {mediaData.media.length === 1 ? 'Item' : 'Items'}
                            </Text>
                            {mediaData.media.length > 1 && (
                                <TouchableOpacity onPress={selectAll} style={styles.selectAllButton}>
                                    <Text style={styles.selectAllText}>
                                        {selectedItems.length === mediaData.media.length ? 'Deselect All' : 'Select All'}
                                    </Text>
                                </TouchableOpacity>
                            )}
                        </View>

                        {/* 3 Column Grid */}
                        <View style={styles.grid}>
                            {mediaData.media.map((item, index) => renderGridItem(item, index))}
                        </View>

                        {/* Info */}
                        <View style={styles.infoContainer}>
                            <Text style={styles.typeText}>
                                {mediaData.media.length > 1 ? 'CAROUSEL' : mediaData.media[0].type.toUpperCase()}
                            </Text>
                            <Text style={styles.descText} numberOfLines={2}>
                                {mediaData.metadata?.title || "Instagram Media"}
                            </Text>
                        </View>

                        {/* Bottom spacing for fixed button */}
                        <View style={{ height: 80 }} />
                    </>
                )}
            </ScrollView>

            {/* Fixed Download Button at Bottom */}
            {mediaData && (
                <View style={styles.bottomButtonContainer}>
                    <TouchableOpacity
                        style={[styles.downloadButton, downloading && styles.buttonDisabled]}
                        onPress={handleDownload}
                        disabled={downloading}
                    >
                        {downloading ? (
                            <ActivityIndicator color="#fff" />
                        ) : (
                            <View style={styles.downloadContent}>
                                <Ionicons name="download" size={20} color="#fff" />
                                <Text style={styles.downloadText}>
                                    {selectedItems.length > 0
                                        ? `Download Selected (${selectedItems.length})`
                                        : 'Select items to download'}
                                </Text>
                            </View>
                        )}
                    </TouchableOpacity>
                </View>
            )}

            {/* Preview Modal */}
            <Modal
                visible={showPreview}
                transparent={true}
                animationType="fade"
                onRequestClose={() => setShowPreview(false)}
            >
                <View style={styles.modalContainer}>
                    <TouchableOpacity
                        style={styles.modalBackdrop}
                        activeOpacity={1}
                        onPress={() => setShowPreview(false)}
                    >
                        <View style={styles.modalContent}>
                            {previewItem?.type === 'video' ? (
                                <VideoView
                                    style={styles.modalVideo}
                                    player={player}
                                    allowsFullscreen
                                    allowsPictureInPicture
                                />
                            ) : (
                                <Image
                                    source={{ uri: previewItem?.url }}
                                    style={styles.modalImage}
                                    resizeMode="contain"
                                />
                            )}
                        </View>
                        <TouchableOpacity
                            style={styles.closeButton}
                            onPress={() => setShowPreview(false)}
                        >
                            <Ionicons name="close-circle" size={40} color="#fff" />
                        </TouchableOpacity>
                    </TouchableOpacity>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
        backgroundColor: '#fff',
    },
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    contentContainer: {
        padding: 20,
        paddingTop: 60,
    },
    header: {
        alignItems: 'center',
        marginBottom: 25,
    },
    logo: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#E1306C',
        marginBottom: 5,
    },
    subtitle: {
        fontSize: 14,
        color: '#666',
        fontWeight: '500',
    },
    searchSection: {
        flexDirection: 'row',
        gap: 10,
        marginBottom: 30,
    },
    input: {
        flex: 1,
        backgroundColor: '#f5f5f5',
        borderRadius: 12,
        padding: 15,
        fontSize: 14,
        borderWidth: 1,
        borderColor: '#e0e0e0',
    },
    searchButton: {
        width: 50,
        height: 50,
        backgroundColor: '#E1306C',
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    resultsHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    resultsTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#000',
    },
    selectAllButton: {
        paddingHorizontal: 15,
        paddingVertical: 8,
        backgroundColor: '#007AFF',
        borderRadius: 20,
    },
    selectAllText: {
        color: '#fff',
        fontSize: 12,
        fontWeight: '600',
    },
    grid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
        marginBottom: 20,
    },
    gridItem: {
        width: '31.5%',
        aspectRatio: 1,
        borderRadius: 10,
        overflow: 'hidden',
        backgroundColor: '#f0f0f0',
        position: 'relative',
    },
    gridImage: {
        width: '100%',
        height: '100%',
    },
    checkboxContainer: {
        position: 'absolute',
        top: 6,
        right: 6,
    },
    checkbox: {
        width: 20,
        height: 20,
        borderRadius: 10,
        borderWidth: 2,
        borderColor: '#fff',
        backgroundColor: 'rgba(0,0,0,0.3)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    checkboxSelected: {
        backgroundColor: '#007AFF',
        borderColor: '#007AFF',
    },
    videoIndicator: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: [{ translateX: -12 }, { translateY: -12 }],
    },
    selectionOverlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 122, 255, 0.2)',
        borderWidth: 2,
        borderColor: '#007AFF',
    },
    infoContainer: {
        marginBottom: 20,
    },
    typeText: {
        fontSize: 11,
        fontWeight: '800',
        color: '#007AFF',
        marginBottom: 5,
    },
    descText: {
        fontSize: 13,
        color: '#666',
        lineHeight: 18,
    },
    bottomButtonContainer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: '#fff',
        paddingHorizontal: 20,
        paddingTop: 10,
        paddingBottom: 20,
        borderTopWidth: 1,
        borderTopColor: '#e0e0e0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 5,
    },
    downloadButton: {
        backgroundColor: '#34C759',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
    },
    buttonDisabled: {
        backgroundColor: '#ccc',
    },
    downloadContent: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    downloadText: {
        color: '#fff',
        fontSize: 15,
        fontWeight: 'bold',
    },
    modalContainer: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.95)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalBackdrop: {
        flex: 1,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContent: {
        width: '90%',
        aspectRatio: 9 / 16,
        backgroundColor: '#000',
        borderRadius: 15,
        overflow: 'hidden',
    },
    modalVideo: {
        width: '100%',
        height: '100%',
    },
    modalImage: {
        width: '100%',
        height: '100%',
    },
    closeButton: {
        position: 'absolute',
        top: 40,
        right: 20,
    },
});
