import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { DISCLAIMER_TEXT } from '../constants/Config';

export default function DisclaimerScreen({ navigation }) {
    const handleAccept = () => {
        // In a real app, we would save the acceptance in AsyncStorage
        navigation.replace('Home');
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.content}>
                <Text style={styles.title}>{DISCLAIMER_TEXT.title}</Text>
                <ScrollView style={styles.scrollContainer}>
                    <Text style={styles.text}>{DISCLAIMER_TEXT.content}</Text>
                </ScrollView>
                <TouchableOpacity style={styles.button} onPress={handleAccept}>
                    <Text style={styles.buttonText}>{DISCLAIMER_TEXT.buttonLabel}</Text>
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    content: {
        flex: 1,
        padding: 30,
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
        color: '#333',
    },
    scrollContainer: {
        marginBottom: 30,
    },
    text: {
        fontSize: 16,
        lineHeight: 24,
        color: '#666',
        textAlign: 'center',
    },
    button: {
        backgroundColor: '#000',
        paddingVertical: 15,
        borderRadius: 8,
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
});
